import connexion
import six

from swagger_server.models.business import Business  # noqa: E501
from swagger_server.models.business_reservation import BusinessReservation  # noqa: E501
from swagger_server.models.business_statistics import BusinessStatistics  # noqa: E501
from swagger_server.models.error import Error  # noqa: E501
from swagger_server.models.inline_response200 import InlineResponse200  # noqa: E501
from swagger_server.models.reservation import Reservation  # noqa: E501
from swagger_server.models.reservation_deleted_ import ReservationDeleted_  # noqa: E501
from swagger_server.models.you_have_a_reservation_in2_hours import YouHaveAReservationIn2Hours  # noqa: E501
from swagger_server import util


def add_reservation(body, user_id, business_id):  # noqa: E501
    """add_reservation

    FR4: The logged in user must be able to set his reservation details in the selected business. FR6: The logged in user must be able to submit his reservation in the system. FR5: The logged in user must be able to select an available hour for his reservation.  # noqa: E501

    :param body: Submit reservation to the system
    :type body: dict | bytes
    :param user_id: User-id of the logged in user that made the reservation
    :type user_id: int
    :param business_id: Business-id of the business that the reservation is made for
    :type business_id: int

    :rtype: Reservation
    """
    if connexion.request.is_json:
        body = Reservation.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def delete_reservation(user_id, reservation_id):  # noqa: E501
    """Deletes a single reservation based on the reservationID supplied

    FR8 - The logged in user must be able to cancel his existing reservation  # noqa: E501

    :param user_id: Retrieve the ID of the user
    :type user_id: int
    :param reservation_id: ID of reservation to delete
    :type reservation_id: int

    :rtype: ReservationDeleted_
    """
    return 'do some magic!'


def get_availability(business_id, reservation_day, reservation_month, reservation_year, number_of_people):  # noqa: E501
    """get_availability

    In order to have the available hours for the specific reservation you want to create.  FR3: The logged in user must be able to start a reservation process by selecting a business  FR5: The logged in user must be able to select an available hour for his reservation.  # noqa: E501

    :param business_id: Business-id of the business that the reservation is made for
    :type business_id: int
    :param reservation_day: The arranged reservation day
    :type reservation_day: int
    :param reservation_month: The arranged reservation month
    :type reservation_month: int
    :param reservation_year: The arranged reservation year
    :type reservation_year: int
    :param number_of_people: The arranged number of people that will be in the reservation
    :type number_of_people: int

    :rtype: InlineResponse200
    """
    return 'do some magic!'


def get_businesses_by_category(category_name):  # noqa: E501
    """get_businesses_by_category

    FR1: The logged in user must be able to view the businesses that are included in the system divided by categories.  # noqa: E501

    :param category_name: The name of the category that the business belongs to.
    :type category_name: str

    :rtype: List[Business]
    """
    return 'do some magic!'


def modify_reservation(body, user_id, reservation_id):  # noqa: E501
    """Modifies a single reservation based on the reservation-id supplied

    FR7 - The logged-in user must be able to modify his reservation  # noqa: E501

    :param body: Reservation to be modified (numberOfPeople, date, time)
    :type body: dict | bytes
    :param user_id: Retrieve the ID of the user
    :type user_id: int
    :param reservation_id: ID of the reservation to modify
    :type reservation_id: int

    :rtype: List[Reservation]
    """
    if connexion.request.is_json:
        body = Reservation.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def notify_user(user_id, reservation_id):  # noqa: E501
    """notify_user

    FR9: The system must be able to notify the logged in user for his reservation at the reservation date. # noqa: E501

    :param user_id: Retrieve the ID of the user
    :type user_id: int
    :param reservation_id: Retrieve the ID of the reservation
    :type reservation_id: int

    :rtype: YouHaveAReservationIn2Hours
    """
    return 'do some magic!'


def search_business_by_keyword(keyword):  # noqa: E501
    """search_business_by_keyword

    FR2: The logged in user must be able to search for a business with a keyword.   # noqa: E501

    :param keyword: The keyword to search for businesses.
    :type keyword: str

    :rtype: List[Business]
    """
    return 'do some magic!'


def view_a_reservation(reservation_id, user_id):  # noqa: E501
    """view_a_reservation

    FR10: The logged in user must be able to view his reservations.  # noqa: E501

    :param reservation_id: Reservation-id of the reservation submitted to the system
    :type reservation_id: int
    :param user_id: User-id of the logged in user that made the reservation
    :type user_id: int

    :rtype: Reservation
    """
    return 'do some magic!'


def view_business_reservations(owner_id, day, month, year):  # noqa: E501
    """view_business_reservations

    FR11: The business owner must be able to view the reservations of his business.  # noqa: E501

    :param owner_id: Owner-id of the business owner
    :type owner_id: int
    :param day: Reservation day
    :type day: int
    :param month: Reservation month
    :type month: int
    :param year: Reservation year
    :type year: int

    :rtype: List[BusinessReservation]
    """
    return 'do some magic!'


def view_business_statistics(owner_id):  # noqa: E501
    """view_business_statistics

    FR12: The business owner must be able to view the statistics of his business reservations.  # noqa: E501

    :param owner_id: Owner-id of the business owner of the business that the reservations were made in.
    :type owner_id: int

    :rtype: List[BusinessStatistics]
    """
    return 'do some magic!'


def view_reservations(user_id):  # noqa: E501
    """view_reservations

    FR10: The logged in user must be able to view his reservations.  # noqa: E501

    :param user_id: User-id of the logged in user that made the reservation
    :type user_id: int

    :rtype: List[Reservation]
    """
    return 'do some magic!'
