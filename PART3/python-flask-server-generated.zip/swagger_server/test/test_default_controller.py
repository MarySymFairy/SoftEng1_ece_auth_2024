# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.business import Business  # noqa: E501
from swagger_server.models.business_reservation import BusinessReservation  # noqa: E501
from swagger_server.models.business_statistics import BusinessStatistics  # noqa: E501
from swagger_server.models.error import Error  # noqa: E501
from swagger_server.models.inline_response200 import InlineResponse200  # noqa: E501
from swagger_server.models.reservation import Reservation  # noqa: E501
from swagger_server.models.reservation_deleted_ import ReservationDeleted_  # noqa: E501
from swagger_server.models.you_have_a_reservation_in2_hours import YouHaveAReservationIn2Hours  # noqa: E501
from swagger_server.test import BaseTestCase


class TestDefaultController(BaseTestCase):
    """DefaultController integration test stubs"""

    def test_add_reservation(self):
        """Test case for add_reservation

        
        """
        body = Reservation()
        query_string = [('user_id', 56),
                        ('business_id', 56)]
        response = self.client.open(
            '/MMAMOUGI_1/RESERVIO_API/1.0.0/reservations',
            method='POST',
            data=json.dumps(body),
            content_type='application/json',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_delete_reservation(self):
        """Test case for delete_reservation

        Deletes a single reservation based on the reservationID supplied
        """
        query_string = [('user_id', 56)]
        response = self.client.open(
            '/MMAMOUGI_1/RESERVIO_API/1.0.0/reservations/{reservation-id}'.format(reservation_id=56),
            method='DELETE',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_availability(self):
        """Test case for get_availability

        
        """
        query_string = [('business_id', 56),
                        ('reservation_day', 56),
                        ('reservation_month', 56),
                        ('reservation_year', 56),
                        ('number_of_people', 56)]
        response = self.client.open(
            '/MMAMOUGI_1/RESERVIO_API/1.0.0/reservations/availability',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_businesses_by_category(self):
        """Test case for get_businesses_by_category

        
        """
        query_string = [('category_name', 'category_name_example')]
        response = self.client.open(
            '/MMAMOUGI_1/RESERVIO_API/1.0.0/businesses',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_modify_reservation(self):
        """Test case for modify_reservation

        Modifies a single reservation based on the reservation-id supplied
        """
        body = Reservation()
        query_string = [('user_id', 56)]
        response = self.client.open(
            '/MMAMOUGI_1/RESERVIO_API/1.0.0/reservations/{reservation-id}'.format(reservation_id=789),
            method='PUT',
            data=json.dumps(body),
            content_type='application/json',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_notify_user(self):
        """Test case for notify_user

        
        """
        query_string = [('user_id', 56)]
        response = self.client.open(
            '/MMAMOUGI_1/RESERVIO_API/1.0.0/reservations/{reservation-id}/notification'.format(reservation_id=56),
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_search_business_by_keyword(self):
        """Test case for search_business_by_keyword

        
        """
        query_string = [('keyword', 'keyword_example')]
        response = self.client.open(
            '/MMAMOUGI_1/RESERVIO_API/1.0.0/businesses/search',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_view_a_reservation(self):
        """Test case for view_a_reservation

        
        """
        query_string = [('user_id', 56)]
        response = self.client.open(
            '/MMAMOUGI_1/RESERVIO_API/1.0.0/reservations/{reservation-id}'.format(reservation_id=56),
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_view_business_reservations(self):
        """Test case for view_business_reservations

        
        """
        query_string = [('owner_id', 56),
                        ('day', 56),
                        ('month', 56),
                        ('year', 56)]
        response = self.client.open(
            '/MMAMOUGI_1/RESERVIO_API/1.0.0/business-reservations',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_view_business_statistics(self):
        """Test case for view_business_statistics

        
        """
        query_string = [('owner_id', 56)]
        response = self.client.open(
            '/MMAMOUGI_1/RESERVIO_API/1.0.0/business-statistics',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_view_reservations(self):
        """Test case for view_reservations

        
        """
        query_string = [('user_id', 56)]
        response = self.client.open(
            '/MMAMOUGI_1/RESERVIO_API/1.0.0/reservations',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
